import { LightningElement,api, wire,track } from 'lwc';
import {refreshApex} from '@salesforce/apex';
import getAccountDetails from '@salesforce/apex/AcoountSearchController.getAccountDetailsByType'
// import standard toast event 
import {ShowToastEvent} from 'lightning/platformShowToastEvent'

import pubsub from 'c/pubsub' ; 
export default class ChildComponent extends LightningElement {
    @track Message;
    @track accType1;
    @track accountsResults;
   
    wiredAccountsResult;

    @wire(getAccountDetails,{type: '$accType1'})
    wiredAccounts(result) {
        console.log(result+'resultresultresultresult');
        this.wiredAccountsResult = result;
        if (result.data) {
            this.accountsResults = result.data;
            this.error = undefined;
        } else if (result.error) {
            this.error = result.error;
            this.accountsResults = undefined;
        }
    }

  
    @api
    showAccounts(accType) {
        
        this.accType1=accType;
        getAccountDetails({
            type: accType
        })
        .then(result => {
            // set @track accounts variable with return contact list from server 
            this.accountsResults = result;
        })
        .catch(error => {
            console.log("In Exception")
            // display server exception in toast msg 
            const event = new ShowToastEvent({
                title: 'Error',
                variant: 'error',
                message: error.body.message,
            });
            this.dispatchEvent(event);
            // reset accounts var with null   
            this.accountsResults = null;
        });

    }

    handleDetails(event){
        console.log("wooow");
        console.log(event.target.value)
        let message = event.target.value;
    
        pubsub.fire('simplevt', message );
        window.console.log('Event Fired ');
    }

    connectedCallback(){
        pubsub.register('pubsubeventforrefreshforeachlist',this.handlepubsubEventRefresh.bind(this));
       
    }
    disconnectedCallback(){
        unregisterAll(this);
    }

    handlepubsubEventRefresh(data){

        console.log('okRefresh');
        refreshApex(this.wiredAccountsResult);
        
    }
}