import { LightningElement,track} from 'lwc';
// import server side apex class method 
import getContactList from '@salesforce/apex/customSearchController.getContactList';
// import standard toast event 
import {ShowToastEvent} from 'lightning/platformShowToastEvent'
 
export default class customSearch extends LightningElement {
    //@track: Marks a property for internal monitoring. A template or function using- 
    //this property forces a component to rerender when the property’s value changes.
    @track accounts;
    sVal = '';
    noRec = 1;
    filterText = '';
    @track accountsResults;
    
 
    // update sVal var when input field value change
    updateSeachKey(event) {
        this.sVal = event.target.value;
    }

    updateRecordsToShow(event) {
        this.noRec = event.target.value;
    }

    updateFilter(event) {
        this.filterText = event.target.value;
    }
 
    // call apex method on button click 
    handleSearch() {
        // if search input value is not blank then call apex method, else display error msg 
        if (this.sVal !== '') {
            getContactList({
                    searchKey: this.sVal,noRec:this.noRec
                })
                .then(result => {
                    // set @track accounts variable with return contact list from server  
                    this.accounts = result;
                    this.accountsResults = result;
                })
                .catch(error => {
                    // display server exception in toast msg 
                    const event = new ShowToastEvent({
                        title: 'Error',
                        variant: 'error',
                        message: error.body.message,
                    });
                    this.dispatchEvent(event);
                    // reset accounts var with null   
                    this.accounts = null;
                });
        } else {
            // fire toast event if input field is blank
            const event = new ShowToastEvent({
                variant: 'error',
                message: 'Search text missing..',
            });
            this.dispatchEvent(event);
        }
    }



    handleFilter(){

       
        let copy=this.accountsResults;
        this.accounts=copy.filter(item=>{
          return  item.Name.includes(this.filterText);
        });
        

    }
}