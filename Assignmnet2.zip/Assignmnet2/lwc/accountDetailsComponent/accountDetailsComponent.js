import { LightningElement,wire,track,api } from 'lwc';
import pubsub from 'c/pubsub' ; 
import showAccountDetails from '@salesforce/apex/AcoountSearchController.getAccountDetails'
import {CurrentPageReference} from 'lightning/navigation';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import OWNER_NAME_FIELD from '@salesforce/schema/Account.Owner.Name';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';
import INDUSTRY_FIELD from '@salesforce/schema/Account.Industry';
import WEBSITE from '@salesforce/schema/Account.Website';
import TYPE from '@salesforce/schema/Account.Type';
import Id_FEILD from '@salesforce/schema/Account.Id';
import {refreshApex} from '@salesforce/apex';
import {ShowToastEvent} from 'lightning/platformShowToastEvent'
export default class PubsubSubscriber extends LightningElement {

    accountId;
    @wire (CurrentPageReference) pageRef;
    @track selectedAccount;
    @track selectedAccountId;
    @track viewMode='Edit';
    @track open=false;

    
    fields=[NAME_FIELD, PHONE_FIELD, INDUSTRY_FIELD,WEBSITE,TYPE,Id_FEILD  ];
    connectedCallback(){
        this.register();
    }
    register(){
        window.console.log('event registered ');
        pubsub.register('simplevt', this.handleEvent.bind(this));
        pubsub.register('pubsubeventforrefresh',this.handlepubsubEventRefresh.bind(this));
    }
    handleEvent(messageFromEvt){
        window.console.log('event handled ',messageFromEvt);
        this.accountId = messageFromEvt;
        console.log(this.accountId);
        showAccountDetails({
            recordId: this.accountId
        })
        .then(result => {
            // set @track accounts variable with return contact list from server 
            this.selectedAccount = result;
        })
        .catch(error => {
            console.log("In Exception")
            // display server exception in toast msg 
            const event = new ShowToastEvent({
                title: 'Error',
                variant: 'error',
                message: error.body.message,
            });
            this.dispatchEvent(event);
            // reset accounts var with null   
            this.selectedAccount = null;
        });


    }

    handleAccoundDetailsChange(event){

        this.updatedAccount=this.selectedAccount;
        
        console.log("In HandleClick");
        const recId =  this.accountId;
        console.log("Selected Account Id:::", recId);
        this.open = true;
     }
     closeModal() {
        console.log("In closeModal");
        this.open = false;
    }

    handleSubmit(event){
        event.preventDefault();       // stop the form from submitting
        const fields = event.detail.fields;
        this.template.querySelector('lightning-record-form').submit(fields);
        this.open = false;
     }
   
     handleSuccess(){
        const evt = new ShowToastEvent({
            title: "Success!",
            message: "The record has been successfully saved.",
            variant: "success",
        });
        this.dispatchEvent(evt);
        this.viewMode='View';
        //fireEvent(this.pageRef,'pubsubeventforrefresh',this.accountId);
        pubsub.fire('pubsubeventforrefresh',this.accountId);
        pubsub.fire('pubsubeventforrefreshforeachlist',this.accountId);
        console.log('fired Event ');
        
     }
     handlepubsubEventRefresh(data){
        console.log('pub sub event listender refresh',data);
        //window.clearTimeout(this.delayTimeout);
        
        showAccountDetails({
            recordId: this.accountId
        })
        .then(result => {
            // set @track accounts variable with return contact list from server 
            this.selectedAccount = result;
        })
        .catch(error => {
            console.log("In Exception")
            // display server exception in toast msg 
            const event = new ShowToastEvent({
                title: 'Error',
                variant: 'error',
                message: error.body.message,
            });
            this.dispatchEvent(event);
            // reset accounts var with null   
            this.selectedAccount = null;
        });
        
    }
}