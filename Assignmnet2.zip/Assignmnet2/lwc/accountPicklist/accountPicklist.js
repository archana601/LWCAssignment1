import { LightningElement, track,wire,api } from 'lwc';
import {
    getPicklistValues
} from 'lightning/uiObjectInfoApi';
import TYPE_FIELD from '@salesforce/schema/Account.Type';

 
 
export default class AccountPicklist  extends LightningElement {

    @track accountType;

    @wire(getPicklistValues, {
        recordTypeId: '012000000000000AAA',
        fieldApiName: TYPE_FIELD,
    })
    picklistValues;


    get options() {

        return this.picklistValues.data?this.picklistValues.data.values:{};
        
    }

    handleAccountTypeChange(event){
        this.accountType=event.detail.value;
       
    }

    handleSearchAccount(event){
      
        this.template.querySelector('c-account-Search-Result').showAccounts( this.accountType);
    }
}

